package com.example.helloworldfx;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class HelloController {

}